# -*- coding: utf-8 -*-
"""
Nítida — UI mínima para etl-mini

- Ejecutar cargas (runner)
- Estado (etl_runs / etl_metrics)
- Explorar tablas DuckDB
- Descargar informe HTML (solo al pulsar botón)
- Subir e importar CSV/XLSX a DuckDB (recursivo data/input/**)
- Modo seguro de ejecución (librería → subprocess UTF-8)

Run:
    python -m streamlit run app/serve.py
"""
from __future__ import annotations

import os
import sys
import re
import subprocess
from pathlib import Path
from datetime import datetime, timezone

import duckdb
import pandas as pd
import streamlit as st

# -------- settings / fallback --------
try:
    from app.utils import load_settings  # si existe
except Exception:
    load_settings = None

DEFAULT_SETTINGS = {
    "paths": {
        "db_path": "data/warehouse.duckdb",
        "reports_dir": "data/reports",
        "parquet_dir": "data/parquet",
    },
    "project": {"name": "etl-mini (Nítida)", "version": "0.4.0"},
}

def get_settings() -> dict:
    if load_settings:
        try:
            return load_settings()
        except Exception:
            pass
    return DEFAULT_SETTINGS

SET = get_settings()
ROOT = Path(__file__).resolve().parents[1]
DB_PATH = (SET.get("paths") or {}).get("db_path", "data/warehouse.duckdb")
REPORTS_DIR = Path((SET.get("paths") or {}).get("reports_dir", "data/reports"))
INPUT_DIR = ROOT / "data" / "input"
INPUT_DIR.mkdir(parents=True, exist_ok=True)

st.set_page_config(page_title="Nítida · ETL-mini", layout="wide")
st.title("Nítida — ETL mini")
st.caption("KPIs rápidos, acciones clave y utilidades sobre DuckDB.")

# -------- conexión única --------
@st.cache_resource(show_spinner=False)
def get_con():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return duckdb.connect(DB_PATH)

def table_or_view_exists(con: duckdb.DuckDBPyConnection, name: str) -> bool:
    q = """
    SELECT 1 FROM information_schema.tables WHERE table_schema='main' AND table_name=?
    UNION ALL
    SELECT 1 FROM information_schema.views  WHERE table_schema='main' AND table_name=?
    LIMIT 1
    """
    return bool(con.execute(q, [name, name]).fetchone())

def df_safe(con: duckdb.DuckDBPyConnection, sql: str) -> pd.DataFrame:
    try:
        return con.execute(sql).fetchdf()
    except Exception:
        return pd.DataFrame()

# -------- helpers UI/KPI --------
def last_run_info(con: duckdb.DuckDBPyConnection) -> dict:
    if not table_or_view_exists(con, "etl_runs"):
        return {}
    df = con.execute("""
        SELECT run_id, status, rows_total, finished_at
        FROM etl_runs
        ORDER BY started_at DESC
        LIMIT 1
    """).fetchdf()
    if df.empty:
        return {}
    row = df.iloc[0]
    finished = row.get("finished_at")
    try:
        if pd.isna(finished):
            local_str = "—"
        else:
            ts = pd.to_datetime(finished, utc=True)
            local_ts = ts.tz_convert(datetime.now().astimezone().tzinfo)
            local_str = local_ts.strftime("%Y-%m-%d %H:%M:%S") + " (hora local)"
    except Exception:
        local_str = str(finished)
    return {
        "run_id": row.get("run_id"),
        "status": row.get("status"),
        "rows_total": int(row.get("rows_total") or 0),
        "finished_local": local_str,
    }

def sanitize_table_name(name: str) -> str:
    base = name
    if "#" in base:
        base = base.split("#", 1)[0]
    base = Path(base).stem.lower()
    base = re.sub(r"[^a-z0-9_]+", "_", base)
    base = re.sub(r"_+", "_", base).strip("_")
    if not base:
        base = "stg_table"
    return f"stg_{base}"

def import_file_to_duckdb(con: duckdb.DuckDBPyConnection, path: Path) -> tuple[str, int]:
    fname = path.name
    table = sanitize_table_name(fname)
    p = str(path)
    sheet_name = None
    if "#" in fname and (fname.endswith(".xlsx") or fname.endswith(".xls")):
        base, sheet_name = fname.split("#", 1)
        path = path.with_name(base)
        p = str(path)

    if fname.lower().endswith((".csv", ".txt")):
        sql = (
            f"CREATE OR REPLACE TABLE {table} AS "
            f"SELECT * FROM read_csv_auto('{Path(p).as_posix()}', "
            f"HEADER=TRUE, SAMPLE_SIZE=-1, NORMALIZE_NAMES=TRUE)"
        )
        con.execute(sql)
    elif fname.lower().endswith((".xlsx", ".xls")):
        try:
            df = pd.read_excel(p, sheet_name=(sheet_name or 0))
        except Exception as e:
            raise RuntimeError(f"No se pudo leer Excel: {e}")
        con.register("df_tmp_import", df)
        con.execute(f"CREATE OR REPLACE TABLE {table} AS SELECT * FROM df_tmp_import")
        con.unregister("df_tmp_import")
    else:
        raise RuntimeError("Formato no soportado (usa CSV/TXT/XLS/XLSX).")

    n = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    return table, int(n)

# -------- vista: Inicio (KPIs + acciones) --------
def render_home(con: duckdb.DuckDBPyConnection):
    st.subheader("Cómo va mi tienda hoy")

    k = last_run_info(con)
    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Último estado", k.get("status", "—"))
    with c2:
        st.metric("Filas del último run", f"{k.get('rows_total', 0):,}".replace(",", "."))
    with c3:
        st.metric("Finalizado", k.get("finished_local", "—"))

    st.markdown("### Acciones rápidas")
    col_run, col_report = st.columns(2)

    # Botón de ejecución (solo modo librería; sin ensure_ledger ni subprocess)
    if col_run.button("▶ Ejecutar hoy", use_container_width=True, type="primary"):
        with st.status("Ejecutando grupo 'daily'…", expanded=True) as st_status:
            try:
                from app.runner import run_group, load_yaml
                cfg = load_yaml("config/sources.yml")
                dq  = load_yaml("config/dq.yml")
                run_status = run_group("daily", cfg, dq)  # "ok" o "fail"
                st_status.update(label=f"Runner OK — status={run_status}", state="complete")
                st.success("Carga completada ✅" if run_status == "ok" else "Carga terminada con incidencias ⚠️")
            except Exception as e:
                st_status.update(label="Error al ejecutar (modo librería)", state="error")
                st.exception(e)
        st.rerun()

    # Informe: preparar y ofrecer descarga solo al pulsar (no genera nada al cargar la página)
    if col_report.button("📄 Preparar informe", use_container_width=True):
        try:
            name, data = prepare_report_download(con)
            st.download_button(
                "⬇️ Descargar informe (HTML)",
                data=data,
                file_name=name,
                mime="text/html",
                use_container_width=True,
            )
        except Exception as e:
            st.warning("El informe no está disponible ahora mismo.")
            st.caption(f"(detalle: {e})")

# -------- vista: Datos (uploader + import + tablas) --------
def render_data(con: duckdb.DuckDBPyConnection):
    st.subheader("Sube tus CSV/XLSX de ventas y mermas")

    uploaded = st.file_uploader(
        "Arrastra aquí archivos CSV/TXT/XLSX/XLS",
        type=["csv", "txt", "xlsx", "xls"],
        accept_multiple_files=True,
    )
    if uploaded:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        for uf in uploaded:
            dest = INPUT_DIR / f"{ts}_{uf.name}"
            dest.parent.mkdir(parents=True, exist_ok=True)
            with open(dest, "wb") as f:
                f.write(uf.getbuffer())
        st.toast("Archivo(s) guardado(s) en data/input/", icon="✅")

    files = sorted(
        [p for p in INPUT_DIR.rglob("*") if p.is_file()],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if files:
        if st.button("📥 Importar TODO a DuckDB (stg_*)", type="primary", use_container_width=True):
            ok, err = 0, 0
            for p in files:
                try:
                    import_file_to_duckdb(con, p)
                    ok += 1
                except Exception:
                    err += 1
            st.success(f"Importación masiva completada: {ok} ok, {err} con error.")
            st.rerun()

        st.markdown("#### Archivos guardados (incluye subcarpetas)")
        for p in files[:50]:
            c1, c2, c3, c4 = st.columns([5, 3, 2, 2])
            with c1:
                try:
                    rel = p.relative_to(INPUT_DIR)
                    st.write(str(rel))
                except Exception:
                    st.write(p.name)
            with c2:
                st.code(sanitize_table_name(p.name), language="bash")
            with c3:
                if st.button("Importar", key=f"imp_{p}"):
                    try:
                        table, n = import_file_to_duckdb(con, p)
                        st.success(f"{table}: {n} filas")
                        st.rerun()
                    except Exception as e:
                        st.error(str(e))
            with c4:
                st.caption(f"{int(p.stat().st_size/1024)} KB")
    else:
        st.info("No hay archivos en data/input/ (puedes crear subcarpetas y arrastrar aquí).")

    st.markdown("#### Mis tablas")
    tdf = df_safe(con, """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema='main'
        ORDER BY table_name
    """)
    if tdf.empty:
        st.info("No hay tablas en 'main'.")
    else:
        sel = st.selectbox("Selecciona una tabla para previsualizar (50 filas)", tdf["table_name"].tolist())
        if sel:
            try:
                prev = con.execute(f"SELECT * FROM {sel} LIMIT 50").fetchdf()
                st.dataframe(prev, use_container_width=True, height=360, hide_index=True)
            except Exception as e:
                st.error(f"No se pudo leer {sel}: {e}")

# -------- vistas secundarias --------
def render_status(con: duckdb.DuckDBPyConnection):
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Últimos runs (etl_runs)")
        if table_or_view_exists(con, "etl_runs"):
            df = con.execute("""
                SELECT run_id, started_at, finished_at, group_name, status, rows_total, duration_s
                FROM etl_runs
                ORDER BY started_at DESC
                LIMIT 20
            """).fetchdf()
            st.dataframe(df, use_container_width=True, height=350, hide_index=True)
        else:
            st.info("No existe etl_runs. Ejecuta un grupo para generar historial.")

    with c2:
        st.subheader("Métricas recientes (etl_metrics)")
        if table_or_view_exists(con, "etl_metrics"):
            df = con.execute("""
                SELECT run_id, source_name, table_name, rows_loaded, dq_pass, dq_violations, duration_s, loaded_at
                FROM etl_metrics
                ORDER BY loaded_at DESC NULLS LAST, run_id DESC
                LIMIT 50
            """).fetchdf()
            st.dataframe(df, use_container_width=True, height=350, hide_index=True)
        else:
            st.info("No existe etl_metrics.")

    st.subheader("Últimas cargas por tabla (v_etl_last)")
    if table_or_view_exists(con, "v_etl_last"):
        df = con.execute("SELECT * FROM v_etl_last ORDER BY loaded_at DESC").fetchdf()
        st.dataframe(df, use_container_width=True, height=260, hide_index=True)
    else:
        st.info("La vista v_etl_last no existe todavía (se crea desde app.status).")

def render_explorer(con: duckdb.DuckDBPyConnection):
    st.subheader("Explorador de tablas/vistas")
    tbls = con.execute("""
        SELECT table_name, table_type
        FROM information_schema.tables
        WHERE table_schema='main'
        UNION ALL
        SELECT table_name, 'VIEW' AS table_type
        FROM information_schema.views
        WHERE table_schema='main'
        ORDER BY table_type, table_name
    """).fetchdf().drop_duplicates(subset=["table_name"])
    if tbls.empty:
        st.info("No hay tablas ni vistas en 'main'.")
        return
    sel = st.selectbox("Selecciona", tbls["table_name"].tolist())
    n = st.slider("Filas a mostrar", 10, 2000, 200, step=10)
    if sel:
        try:
            df = con.execute(f"SELECT * FROM {sel} LIMIT {int(n)}").fetchdf()
            st.dataframe(df, use_container_width=True, height=420)
        except Exception as e:
            st.error(f"No se pudo leer {sel}: {e}")

# -------- Modo seguro (librería → subprocess UTF-8) --------
def render_safe_mode():
    """Ejecutar 'daily' en modo seguro (subprocess) y refrescar métricas."""
    st.divider()
    st.subheader("Modo seguro — ejecutar y refrescar")

    col1, col2 = st.columns(2)
    ROOT_L = Path(__file__).resolve().parents[1]

    # Botón: ejecutar runner por subprocess (robusto, sin ensure_ledger)
    if col1.button("▶ Ejecutar daily (modo seguro)", use_container_width=True):
        with st.status("Ejecutando 'daily' (subprocess)…", expanded=True) as s:
            try:
                env = os.environ.copy()
                env["PYTHONUTF8"] = "1"
                env["PYTHONIOENCODING"] = "utf-8"
                res = subprocess.run(
                    [sys.executable, "-m", "app.runner", "--group", "daily"],
                    cwd=str(ROOT_L),
                    capture_output=True,
                    text=True,
                    env=env,
                )
                if res.stdout:
                    st.code(res.stdout, language="bash")
                if res.returncode != 0:
                    s.update(label="Runner terminó con error", state="error")
                    if res.stderr:
                        st.code(res.stderr, language="bash")
                    st.error("Fallo al ejecutar el runner.")
                else:
                    s.update(label="Runner OK", state="complete")
                    st.toast("Carga finalizada", icon="✅")
            except Exception as e:
                s.update(label="Error al ejecutar subprocess", state="error")
                st.exception(e)
        st.rerun()

    # Botón: refrescar KPIs
    if col2.button("↻ Refrescar métricas", use_container_width=True):
        st.rerun()

    # Tabla de últimos runs
    try:
        con = get_con()
        runs = con.execute("""
            SELECT run_id, started_at, finished_at, group_name, status, rows_total, duration_s
            FROM etl_runs
            ORDER BY started_at DESC
            LIMIT 10
        """).fetchdf()
        st.dataframe(runs, use_container_width=True, height=260, hide_index=True)
    except Exception as e:
        st.info(f"No se pudieron leer KPIs: {e}")

# -------- main --------
def main():
    con = get_con()
    tabs = st.tabs(["Inicio", "Estado", "Explorar", "Datos"])

    with tabs[0]:
        render_home(con)

    with tabs[1]:
        render_status(con)
        render_safe_mode()

    with tabs[2]:
        render_explorer(con)

    with tabs[3]:
        render_data(con)


if __name__ == "__main__":
    main()
